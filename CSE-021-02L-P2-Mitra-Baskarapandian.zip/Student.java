import java.util.Date;

public class Student {
	private String name;
	private char gender;
	private Date birthdate;
	private Preference pref;
	private boolean matched;
	private int month;
	private int day;
	private int year;
	public int cScore;

	public Student() {
		name = "";
		gender = 'M';
		matched = false;
		birthdate = new Date(month, day, year);
	}

	public Student(String name, char gender, Date birthdate, Preference pref) {
		this.name = name;
		this.gender = gender;
		this.birthdate = birthdate;
		this.pref = pref;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	public void setPreference(Preference pref) {
		this.pref = pref;
	}

	public void setMatched(boolean matched) {
		this.matched = matched;
	}

	public String getName() {
		return name;
	}

	public char getGender() {
		return gender;
	}

	public Date getBirthdate() {
		return birthdate;
	}

	public Preference getPref() {
		return pref;
	}

	public boolean getMatch() {
		return matched;
	}

	public void SetMatched() {
		matched = true;

	}

	public int compare(Student student) {
		if (gender != student.gender)
			return 0;
		cScore = (40 - pref.compare(student.pref)) + (60 - birthdate.compareTo(student.birthdate));

		if (cScore < 0)
			return 0;
		else if (cScore > 100)
			return 100;
		return cScore;
	}

}
