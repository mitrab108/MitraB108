import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.Math;
import java.text.DecimalFormat;
public class Recipt {	
	private static DecimalFormat df = new DecimalFormat("0.00");
	public static void main (String[] args) throws FileNotFoundException 
	{
		Scanner scan  = new Scanner (System.in);
		System.out.println("Please enter the file name that you want to use.");
		String filename = scan.nextLine();
		File txt = new File(filename);
		Scanner key = new Scanner(txt);
		ArrayList<String> arr = new ArrayList<String>();
		while(key.hasNextLine()){
		    arr.add(key.nextLine());
		}
		String[] entry = arr.toArray(new String[]{});
		int MAX = entry.length;
		
		int[] quant = new int[MAX];
		String[] item = new String[MAX];
		boolean[] type = new boolean[MAX];
		boolean[] in = new boolean[MAX];
		double[] price = new double[MAX];
		double[] tax = new double[MAX];
		double totalTax = 0;
		double total = 0;
		
		for(int i = 0; i < MAX; i++)
		{
				String[] input = entry[i].split("\\s+");
				quant[i] = Integer.valueOf(input[0]);
				price[i] = Double.valueOf(input[input.length - 1]);
				String line = "";
				for(int k = 1; k < input.length - 2; k++)
				{
					line += (input[k] + " ");
				}
				item[i] = line.substring(0, line.length()-1);
				for(int k = 0; k < input.length; k++)
				{
					if(input[k].equalsIgnoreCase("chocolate") || input[k].equalsIgnoreCase("chocolates") || input[k].equalsIgnoreCase("book") || input[k].equalsIgnoreCase("pills"))
					{
						type[i] = false;
						break;
					}
					else
					{
						type[i] = true;
					}
					
				}
				for(int k = 0; k < input.length; k++)
				{
					if(input[k].equalsIgnoreCase("imported"))
					{
						in[i] = true;
						break;
					}
					else
					{
						in[i] = false;
					}
					
				}
				if(in[i] == true)
				{
					if(type[i] == true)
					{
						tax[i] = (price[i]*0.15);
					}
					else
					{
						tax[i] = (price[i] * 0.5);
					}
				}
				else
				{
					if(type[i] == true)
					{
						tax[i] = (price[i] * 0.1);
					}
					else
					{
						tax[i] = 0;
					}
				}
			
		}
		for(int i = 0; i < quant.length; i++)
		{
				System.out.println(quant[i] + " " + item[i]+ ": " + df.format(price[i]+tax[i]));
				total += (price[i] + tax[i]);
				totalTax += tax[i];
		}
		System.out.println("Sales Taxes: " + df.format(totalTax));
		System.out.println("Total: " + df.format(total));
		
		
		
	}
}
